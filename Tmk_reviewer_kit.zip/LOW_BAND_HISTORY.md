# Low-frequency certificate: which subdivision to use

This note accompanies §6, Table 2 and §7 of *Logarithmic Inequalities of Arbitrary Order for the Riemann Xi Coefficients* (revision of 31 October 2026). The quantities below already include both signs of the frequency and the normalization 1/(2π).

| Calculation on the 0–128 band | Local tolerance on a working interval [a,b] | Computed upper bound | Role |
|---|---|---|---|
| Original default | 10⁻⁴(b−a) | 0.00365973181145… | Historical. Does not certify the earlier target 0.003552; not used in Table 2. |
| Adopted refined partition | 5·10⁻⁵(b−a) | 0.0026037475896184… | 2,286 closed cells; gives the strict Table 2 bound 0.002604. |

Both runs are preserved. The subdivision and the outward handling of cached Taylor-tail bounds changed; the comparison transform, theta evaluator and isolated root did not. The adopted entry point in the original archive is `low_0_128/certify_refined.py`; `low_0_128/run_refined.py` drives the available refined models. For the evidence used by the final rational assembly, see `assemble_end_to_end.py` at the root of the same archive. Read the JSON `checks_count` field for the substantive check count; the legacy console also counts eight tests inserted while results are serialized. This affects the displayed count, not the boundary bound.

For records stored as binary endpoints, the rational assembly decodes their exact binary values. For the explicitly identified older, decimal-only displayed upper bounds it adds an outward guard of 10⁻⁴⁰ where indicated by the assembler. The guard concerns display rounding at the stored magnitudes/precision, not errors in the underlying analytic estimate. The default and refined results are not averaged or combined. The current Table 2 uses the refined value exclusively.
