# Evidence index

All paths in the following table are relative to `tmk_certified_audit_20260929/` after extracting `tmk_certified_audit_20260929.zip`. Digests identify the actual files supplied.

| Appendix D / claim | File | SHA-256 |
|---|---|---|
| Origin coefficients and Gauss weights | `low_0_128/input_revalidation.json` | `8c2f7c0f345d371d52a9e3c7fb888544767e38f36ed302b01ddb66e46a31220a` |
| Origin coefficients and Gauss weights | `low_0_128/revalidate_inputs.py` | `64a92a0c28ce12acc6ddc4d238e3136b3d4c8850fc17294d02c6af934b25b6b3` |
| Root | `low_0_128/root_refinement.json` | `adce6be430218fff6a5d55ad8ab651b2df45f1d626411cc28aa8bba0aa09aeb2` |
| Root | `independent/root_delta64.py` | `eb85504b48cfa83ad0f0feb321ededf155537d60593f73612805f4a02fc5984e` |
| Comparison density | `comparator/certify_new_comparator.py` | `017692a91df336d7b49c11825fdae3680dd1b03a99bcfb9248e4bc7b955ae062` |
| Comparison density | `comparator/new_comparator_certificate.json` | `ee5d844a8d9873b641454da059d1c96dd0c4470f5d5d6189136cb06cbfb8bb3e` |
| 0–128 | `low_0_128/certify_refined.py` | `09c231305de9f9ce4cb4e99eca6c100d0ae463e41ba825db566b2d5029f3aa96` |
| 128–256 and 256–512 | `mid_128_256/proof_ja.md` | `c6cab4bc56e0e7a4e3554e4dae26700214e56e9d91b7a71e9b011aa554750408` |
| 128–256 and 256–512 | `high_256_512/proof_ja.md` | `f7ae2affcbe5cd0a6c86d05bc581855f9900cb2dac5840b5ec3a40dec8c38425` |
| 512–2560 | `band_512_2560/contour_models.py` | `0057ad38d069afe7971c2f105770f13fc6d16509db8201d0b3e5e4ea1e6bc56e` |
| Winding number | `high_256_512/rectangle_zero_certificate.json` | `17fb42013dcbc33d2ab9a3393b3aacd910290a5983308f85f92429a60afe2cfa` |
| Winding number | `band_512_2560/global_winding_certificate.json` | `cfe5286621d9af37609374e2a46598914fa5eaee6b702317e6e76100e7863511` |
| Intermediate saddle and tail | `coarse_tail/reproduce.py` | `f1d9627fda290fcf2b8e462fe01503df29edb1d690e9df88c7e47cdabffb50e2` |
| Intermediate saddle and tail | `coarse_tail/assemble_tail.py` | `220238302990efedef0ebafac05532e5c8e634ddc7ac8381925632a9413e486e` |
| Infinite region | `infinite_tail/proof_ja.md` | `c6d5b54600954dbe7ba225ac43e58238ae486284b3f27d49320cdebcccb64c82` |
| Infinite region | `infinite_tail/verify_algebra.py` | `c48222e3c999738e0687508e58ad7ccc658d34aa3835b9be056ce77348d62eea` |
| Infinite region | `infinite_tail/verify_constants.py` | `cfc3e93b5fa922ccad9341d4ad273459e6fb80982011b489481892ff10d777d6` |
| Assembly | `assemble_end_to_end.py` | `4e49a6f7457afc060e7f2c3574f6b448927fb293a450ce5341955a500f0bdef1` |

