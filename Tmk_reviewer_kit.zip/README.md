# Review copy: manuscript and numerical replay

Open `Tmk_EN_revised.pdf` first. To rerun the exact certificate assembly and the alternate-root calculation, extract `tmk_certificate_replay_20261003.zip`, enter `tmk_certificate_replay/`, follow its dependency instructions, and run `python3 run_checks.py --output ./my-new-run` in a fresh output directory. For stored-certificate checks only, use `--exact-only`. Prior subdivision choices are explained in `LOW_BAND_HISTORY.md`. The included logs in `audit/` were produced for this revision; they are not a substitute for a reader’s own run.

The full 98,381,169-byte original numerical archive and actual regenerated saddle files are deliberately not in this lightweight package. For these, obtain the separate `Tmk_numerical_supplement.zip`. The complete supplement contains `tmk_certified_audit_20260929.zip`, the replay archive, documentation and logs. Appendix D and `EVIDENCE_INDEX.md` refer to the full source archive, not the lightweight kit.
