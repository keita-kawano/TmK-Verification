"""Compare the exact binary endpoints of all saddle cells in two generation runs.
Usage: python3 check_regen.py original_coarse_dir regenerated_coarse_dir output.json
"""
import sys,json,hashlib
from pathlib import Path

def cells(p):
    data={}; parts=[]
    for f in sorted(p.glob('relative_saddle_certificate_*.json')):
        j=json.loads(f.read_text()); assert j['failures']==[]
        parts.append(f.name)
        for row in j['cells']:
            k=row['i'];assert row['ok'] and k not in data
            data[k]=row['total']['binary']
    assert sorted(data)==list(range(30000,49200))
    return data,parts
x,y,o=map(Path,sys.argv[1:]); a,ap=cells(x); b,bp=cells(y); ae=json.loads((x/'tail_envelope_certificate.json').read_text());be=json.loads((y/'tail_envelope_certificate.json').read_text());key='2560'; r=be['results'][key]; eq=(a==b); qeq=ae['results'][key]==r; assert eq and qeq and be['all_pass']
out={'status':'PASS','closed_cells':len(a),'indices_inclusive':[min(a),max(a)],'old_partition_files':len(ap),'new_partition_files':len(bp),'both_exact_binary_endpoints_match_for_every_cell':eq,'same_block_envelope_as_archived':qeq,'number_of_integration_blocks':len(r['blocks']),'maximum_F_upper':be['max_relative_bound']['hi'],'middle_band_upper':r['middle_envelope']['hi'],'far_tail_certified_upper':r['inherited_tail'],'total_tail_upper':r['tail_from_T']['hi'],'scope':'Full regeneration of intermediate saddle cells with original algorithm; not independent verification of analytic derivations.'};o.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
